
Symmetry Innovations Pty Ltd

Python for QNX6 package. 
This software is made available under the MIT License.

PyQNX6 is a series of modules that expose the functionality of QNX6 
via python. This allows the user to interactively create servers, clients,
use timers, interrupts and to create Resource Managers. 

For more details see http://symmetry.com.au/PyQNX6 for the user manual and
details of updates.



